
import { Table, Container, Button } from 'react-bootstrap'
import {PianoStudi} from './PianoStudi'


function ListaCorsi(props) {

    let crediti_tot = 0;
    let array_crediti = props.pianoStudiBis.map(c => c.crediti);
    if (array_crediti === []) crediti_tot = 0;
    else array_crediti.forEach((c) => crediti_tot += c)


    return (
        <>
            <Container fluid>
                <h1 className="text-primary text-center">Laurea Magistrale in Ingegneria Informatica</h1>
                <h2 className="text-center">Corsi Erogati </h2>
                <Table striped bordered hover size="sm">
                    <thead>
                        <tr>
                            <th>Codice</th>
                            <th>Nome</th>
                            <th>Crediti</th>
                            <th>Studenti Attuali</th>
                            <th>Max Studenti</th>
                            <th></th>
                        </tr>

                    </thead>
                    
                    <tbody  >

                        {props.corsi.sort((a, b) => {
                            if (a.nome > b.nome) return 1;
                            else return -1;
                        }).map((c) => c.esteso === 0 ? 
                            <CourseRow key={c.codice} corso={c} corsi={props.corsi}
                            setCorsi={props.setCorsi} loggedIn={props.loggedIn} addCourse={props.addCourse} />
                            :
                            <CourseRowExp key={c.codice} corso={c} corsi={props.corsi} setCorsi={props.setCorsi} />)}


                    </tbody>
                </Table>

                <PianoStudi corsi={props.corsi} setCorsi={props.setCorsi} loggedIn = {props.loggedIn} 
                pianoStudi = {props.pianoStudi} setPianoStudi = {props.setPianoStudi} user= {props.user} setUser = {props.setUser} 
                addCourse = {props.addCourse} deleteCourse = {props.deleteCourse} 
                saveStudyPlan = {props.saveStudyPlan } deleteStudyPlan = {props.deleteStudyPlan} 
                pianoStudiAppenaCreato = {props.pianoStudiAppenaCreato} setpianoStudiAppenaCreato= {props.setpianoStudiAppenaCreato}
                message2 = {props.message2} setMessage2={props.setMessage2} crediti_tot = {crediti_tot} 
                pianoStudiBis = {props.pianoStudiBis} setpianoStudiBis = {props.setpianoStudiBis}
                > </PianoStudi>
                </Container>
                </>
    );}

function CourseRowExp(props) {

    function richiudiCorso(codice_corso) {

        let corsi = [...props.corsi];
        corsi = corsi.map(c => {
            if (c.codice === codice_corso) {
                return {
                    codice: c.codice, nome: c.nome, crediti: c.crediti, studentiAttuali: c.studentiAttuali, maxStudenti: c.maxStudenti,
                    incompatibilita: c.incompatibilita, propedeutico: c.propedeutico, esteso: 0
                }
            }
            return c;
        });
        props.setCorsi(corsi);

    }

    return (

        <>
            <tr>
                <td>{props.corso.codice}</td>
                <td>{props.corso.nome}</td>
                <td>{props.corso.crediti}</td>
                {props.corso.studentiAttuali ? <td>{props.corso.studentiAttuali}</td> : <td></td>}
                {props.corso.maxStudenti ? <td>{props.corso.maxStudenti}</td> : <td></td>}
                <td></td>

            </tr>

            <tr>
                <th>Codici dei corsi incompatibili: </th>
                <td>{props.corso.incompatibilita} </td>

                <td></td>
                <td></td>
                <td></td>
                <td></td>

            </tr>

            <tr>

                <th>Codice corso propedeutico: </th>
                <td>{props.corso.propedeutico}</td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <svg onClick={() => richiudiCorso(props.corso.codice)} xmlns="http://www.w3.org/2000/svg" width="24" height="24" fillRule="currentColor" className="bi bi-arrow-90deg-up" viewBox="0 0 16 16">
                        <path fillRule="evenodd" d="M4.854 1.146a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L4 2.707V12.5A2.5 2.5 0 0 0 6.5 15h8a.5.5 0 0 0 0-1h-8A1.5 1.5 0 0 1 5 12.5V2.707l3.146 3.147a.5.5 0 1 0 .708-.708l-4-4z" />
                    </svg>
                </td>

            </tr>


        </>
    );

}

function CourseRow(props) {

  let statusClass = null;
  
  switch(props.corso.warning) {
    case 0:
      break;
    case 1:
      statusClass = 'warningRiga';
      break;
    default:
      break;
  }

    return (
        <>
            <tr className={statusClass} ><CourseData corso={props.corso} corsi={props.corsi} setCorsi={props.setCorsi} />
                {props.loggedIn ? <><td>
                    <Button onClick={() => { props.addCourse(props.corso) }} variant="success">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                            <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z" />
                        </svg> </Button>
                </td>
                </> : false}
            </tr>


        </>
    );
}

function CourseData(props) {

    function espandiCorso(codice_corso) {

        let corsi = [...props.corsi];
        corsi = corsi.map(c => {
            if (c.codice === codice_corso) {
                return {
                    codice: c.codice, nome: c.nome, crediti: c.crediti, studentiAttuali: c.studentiAttuali, maxStudenti: c.maxStudenti,
                    incompatibilita: c.incompatibilita, propedeutico: c.propedeutico, esteso: 1
                }
            }
            return c;
        });
        props.setCorsi(corsi);

    }



    return (
        <>
            <td>{props.corso.codice}</td>
            <td>{props.corso.nome}</td>
            <td>{props.corso.crediti}</td>
            <td>{props.corso.studentiAttuali}</td>
            {props.corso.maxStudenti ? <td>{props.corso.maxStudenti}</td> : <td></td>}
            <td><svg onClick={() => espandiCorso(props.corso.codice)} xmlns="http://www.w3.org/2000/svg" width="24" height="24" fillrull="currentColor" className="bi bi-three-dots" viewBox="0 0 16 16">
                <path d="M3 9.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" />
            </svg>
            </td>



        </>
    );
}

export { ListaCorsi };
import { Container, Navbar, Image, Modal, Button, Row, Col} from 'react-bootstrap';
import { useNavigate} from 'react-router-dom';
import {LogoutButton} from './LoginForm';
import { useState} from 'react';

function NavBar(props) {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const navigate = useNavigate();
    
  return (
    <>

  <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Ciao, {props.user.nome} {props.user.cognome}</Modal.Title>
            </Modal.Header>
            <Modal.Body><strong>Email:</strong> {props.user.username}</Modal.Body>
            <Modal.Body><strong>Matricola:</strong> {props.user.matricola}</Modal.Body>
            <Modal.Body><strong>Carriera:</strong> {props.user.carriera === 0 ? 'None' : 
            props.user.carriera === 2 ? 'Full-time' : 'Part-time'}</Modal.Body>
            <Modal.Footer>
                <Button variant="primary" onClick={handleClose}>
                    Close
                </Button>
                <Row>
                    <Col onClick={handleClose} >
                     <LogoutButton onClick = { () => props.setloggedIn(false)} logout={props.doLogOut} user={props.user} setUser = {props.setUser}/> 
                    </Col>
                </Row>
            </Modal.Footer>
        </Modal>

      <Navbar bg="info" expand="lg" className='shadow mb-4'>
        <Container fluid>
          <Navbar.Brand>
            
              <Image src={require('./Logo_PoliTo.png')} width='150' height='70'></Image>
            
          </Navbar.Brand>
          
          <Navbar.Brand>

          {props.loggedIn ? 
              <div>
              Effettua Logout { }
              <svg onClick={handleShow} xmlns="http://www.w3.org/2000/svg" width="45" height="45" fillRule="currentColor" className="bi bi-person-circle" viewBox="0 0 16 16">
              <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
              <path fillRule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
            </svg> 
              </div>
              :

              <div>
                Effettua Login { }
            <svg onClick = {() => navigate('/login') } xmlns="http://www.w3.org/2000/svg" width="45" height="45" fillRule="currentColor" className="bi bi-person-circle" viewBox="0 0 16 16">
              <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
              <path fillRule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
            </svg>  </div>
          }
          </Navbar.Brand>
        </Container>

      </Navbar>
    </>
  );
}

export { NavBar };
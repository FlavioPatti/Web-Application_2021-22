
import {Button, Form} from 'react-bootstrap'

function FormPianoStudi(props) {

    let carr = 0;

    const handleSubmit = (event) => {
        event.preventDefault();
        if(carr===1 || carr ===2){
        props.setpianoStudiAppenaCreato(true);
        props.setUser(user => {return {matricola: user.matricola, username: user.username, nome: user.nome, 
                cognome: user.cognome, carriera: carr}})
        props.setMessage2({msg: "Piano di studi creato!", type: 'success'});
        }else{
            props.setMessage2({msg: "Selezionare un'opzione di studi!", type: 'danger'});
        }
        
    }

    return (

        <>
            <h2>Clicca sul bottone "Crea Piano di Studi" per creare un tuo piano di studi personalizzato</h2>
            <p>Specifica l’opzione full-time o part-time per il piano di studi che vuoi creare </p>
            <Form>
                {['radio'].map((type) => (
                    <div key={`inline-${type}`} className="mb-3">
                        <Form.Check onClick={( ()=> {carr = 2 })}
                            inline
                            label="Full-time"
                            name="group1"
                            type={type}
                            id={`inline-${type}-1`}
                        />
                        <Form.Check onClick={( ()=> { carr = 1})}
                            inline
                            label="Part-time"
                            name="group1"
                            type={type}
                            id={`inline-${type}-2`}

                        />
                    </div>
                ))}
            </Form>
            <Button onClick={handleSubmit}>Crea Piano di Studi</Button> 
                    </>   
)
};

export { FormPianoStudi };
import { Form, Button, Alert, Container, Row, Col} from 'react-bootstrap';
import { useState } from 'react';
import validator from 'validator';

function LoginForm(props) {
    const [email, setEmail] = useState('test@polito.it');
    const [password, setPassword] = useState('password');
    const [errorMessage, setErrorMessage] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();

        let valid = true;

        if (password.length <= 6) {
            valid = false;
            props.setMessage({msg: "Password non valida, deve contenere almeno 7 caratteri", type: 'danger'})
        }

        if (!validator.isEmail(email)) {
            valid = false;
               props.setMessage({msg: "Email non valida", type: 'danger'})
        }



        if (valid) {
            var credentials = {
                username: email,
                password: password
            }

            try {
                await props.login(credentials);
            } catch (err) {
                setErrorMessage(err);
            }

        } else {
            setErrorMessage('Email e/o password invalide');
        }

    };

    return (
    <Container fluid>
        <Row className="justify-content-center">
            <Col sm='6'>
                <h2>Login Politecnico di Torino</h2>
            </Col>
        </Row>
        <Row className="justify-content-center">
            <Col sm='6'>
                <Form>
                    {errorMessage ? <Alert variant='danger'> {errorMessage}</Alert> : ''}
                    <Form.Group controlId='email'>
                        <Form.Label>Email</Form.Label>
                        <Form.Control type='email' value={email} onChange={ev => setEmail(ev.target.value)} />
                    </Form.Group>
                    <Form.Group controlId='password'>
                        <Form.Label>Password</Form.Label>
                        <Form.Control type='password' value={password} onChange={ev => setPassword(ev.target.value)} />
                    </Form.Group>
                    <Button onClick={handleSubmit}>Login</Button>
                </Form>
            </Col>
        </Row>
    </Container>
    )
}

function LogoutButton(props) {
    return (
        <Col> 
            
            <Button variant="outline-primary" onClick={() => {props.logout()}}>Logout</Button>
        </Col>
    )
}

export { LoginForm, LogoutButton }
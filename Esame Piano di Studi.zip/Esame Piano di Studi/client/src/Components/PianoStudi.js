import { Table, Row, Col, Button, Alert } from 'react-bootstrap'
import { FormPianoStudi } from './FormPianoStudi'


function PianoStudi(props) {

    return (
        <>
        {props.message2 && <Row>
            <Alert variant={props.message2.type} onClose={() => props.setMessage2('')} dismissible>{props.message2.msg}</Alert>
        </Row>}
    
    
       { props.loggedIn ?
        <>
            <h1 className="text-primary text-center"> Piano Di Studi Matricola: {props.user.matricola} </h1>

            {props.user.carriera === 0 ?

                <FormPianoStudi user={props.user} setUser={props.setUser}
                    message2={props.message2} setMessage2={props.setMessage2}
                    pianoStudiAppenaCreato={props.pianoStudiAppenaCreato} setpianoStudiAppenaCreato={props.setpianoStudiAppenaCreato} />

                : props.user.carriera === 2 ?
                    <>
                        <h2>  Totale crediti: {props.crediti_tot} </h2>
                        <Row>
                            <Col className='col-6'>
                                <h3> Min Crediti: 60 </h3>
                            </Col>
                            <Col className='col-6'>
                                <h3> Max Crediti: 80 </h3>
                            </Col>
                        </Row>
                    </>
                    :
                    <>
                        <h2>  Totale crediti: {props.crediti_tot} </h2>
                        <Row>
                            <Col className='col-6'>
                                <h3> Min Crediti: 20 </h3>
                            </Col>
                            <Col className='col-6'>
                                <h3> Max Crediti: 40 </h3>
                            </Col>
                        </Row>
                    </>
            }
            <Table striped bordered hover size="sm">

                {props.user.carriera !== 0 ?
                    <>
                        <thead>
                            <tr>
                                <th>Codice</th>
                                <th>Nome</th>
                                <th>Crediti</th>

                            </tr>
                        </thead>

                        <tbody>

                            {props.pianoStudiBis.map((c) => <StudyPlanRow key={c.codice} corsi={props.corsi} deleteCourse={props.deleteCourse} corso={c} />)}

                        </tbody>
                    </> : false}
            </Table>
        </>
        : false}
    
    
        {props.loggedIn && props.user.carriera !== 0 ?
        <Row>
            <Col>
                <Button onClick={() => { props.saveStudyPlan() }} variant='success'>Salva</Button>
            </Col>
            <Col>
                <Button variant='danger' onClick={() => props.setpianoStudiBis(props.pianoStudi)} >Annulla</Button>
            </Col>
            <Col>
                <Button onClick={() => { props.deleteStudyPlan(); }} variant='dark'>Cancella Piano di Studi</Button>
            </Col>
        </Row>
        : false}
        </>
    );

}

function StudyPlanRow(props) {



    return (

        <>
            <tr>
                <td>{props.corso.codice}</td>
                <td>{props.corso.nome}</td>
                <td>{props.corso.crediti}</td>
                <td>
                    <Button onClick={() => { props.deleteCourse(props.corso) }} variant="danger">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fillRule="currentColor" className="bi bi-trash3-fill" viewBox="0 0 16 16">
                            <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z" />
                        </svg> </Button>
                </td>
            </tr>



        </>
    );

}


export { PianoStudi };
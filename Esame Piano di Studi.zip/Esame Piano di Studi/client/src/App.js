import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useState, useEffect, useContext} from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { ListaCorsi } from './Components/ListaCorsi';
import { Container, Row, Alert, Toast, ToastContainer } from 'react-bootstrap';
import { NavBar } from './Components/NavBar';
import API from './API';
import {LoginForm} from './Components/LoginForm';
import MessageContext from './messageCtx';

function App() {

  //ERRORI LATO SERVER: user non autenticato, unknow error quando stacco il server

  const [message, setMessage] = useState('');
  // If an error occurs, the error message will be shown in a toast.
  const handleErrors = (err) => {
    let msg = '';
    if (err.error) msg = err.error;
    else if (String(err) === "string") msg = String(err);
    else msg = "Unknown Error";
    setMessage(msg); // WARN: a more complex application requires a queue of messages. In this example only last error is shown.
  }

  return (
    <Router>
      <MessageContext.Provider value={{ handleErrors }}>
        <Container fluid className="App">
          <Routes>
            <Route path="/*" element={<Main />} />
          </Routes>
          <ToastContainer className='mt-1' position='top-center'>
          <Toast bg='danger text-light' show={message !== ''} onClose={() => setMessage('')} delay={4000} autohide>
            <Toast.Body>{ message }</Toast.Body>
          </Toast>
          </ToastContainer>
        </Container>
      </MessageContext.Provider>
    </Router>
  )
}


function Main() {

  const [corsi, setCorsi] = useState([]);
  const [loggedIn, setloggedIn] = useState(false);
  const [user, setUser] = useState({});
  const [message, setMessage] = useState(''); //message up
  const [message2, setMessage2] = useState(''); //message down
  const [pianoStudi, setPianoStudi] = useState([]);
  const [pianoStudiBis, setpianoStudiBis] = useState([]); //il secondo piano di studi mi serve per gestire il bottone di annulla
  const [pianoStudiAppenaCreato, setpianoStudiAppenaCreato] = useState(false); 
  const {handleErrors} = useContext(MessageContext);

  const navigate = useNavigate();

  useEffect(()=> {
    const checkAuth = async() => {
      try {
        const user = await API.getUserInfo();
        setloggedIn(true);
        setUser(user);
      } catch(err) {
        handleErrors(err);
      }
    };
    checkAuth();
  }, []); //render solo all'inizio

  useEffect(() => {
    try{
      API.getAllCourses()
        .then((courses) => {
          setCorsi(courses);
        })
    } catch(err) {handleErrors(err) }    }
  , [loggedIn]) 

  useEffect(() => {
    try{
    API.getStudyPlan()
    .then((courses)=> {
      setPianoStudi(courses);
      setpianoStudiBis(courses);
    }) }
    catch(err){ if(loggedIn) handleErrors(err) } //solo se sono loggato mi deve fare errore
  }, [loggedIn, user.carriera]) //render all'inizio e ogni volta che cambia uno dei due
  //quando faccio la delete cancello il piano di studi e setto carriera a 0 quindi aggiorno il piano studi

  const doLogIn =async (credentials) => {
    try{
    const user = await API.logIn(credentials)
      setloggedIn(true)
      setUser(user)
      setMessage({msg: `Benvenuto, ${user.matricola}!`, type: 'success'})
      navigate('/') 
  }catch(err) { throw err;}
  }
  

const doLogOut = async () => {
  try { 
  await API.logOut();
  setloggedIn(false);
  setUser({});
  setCorsi([]);
  }catch (err) {handleErrors(err)}
  
  
}


const saveStudyPlan = async () => {

  let newcourses = [];
  for (let i = 0; i < pianoStudiBis.length; i++) {
    newcourses[i] = pianoStudiBis[i].codice;
  }
  
   let tot_crediti=0;
   let array_crediti = pianoStudiBis.map(c => c.crediti);
   if(array_crediti === []) tot_crediti= 0;
   else array_crediti.forEach((c) => tot_crediti += c)
  

if(user.carriera!==0 && pianoStudiBis.length>0){
//carriera = 0 => null, carriera = 1 => part-time, carriera = 2 => full-time

  if(user.carriera === 2){
  if(tot_crediti>=60 && tot_crediti<=80){

    if(pianoStudiAppenaCreato===false){  //se non ho appena creato il piano studi devo fare la delete prima della save
    
     try{
      await API.updateStudentiAttuali(-1)
      await API.deleteStudyPlan()
      await API.saveStudyPlan(newcourses)
      await API.updateStudentiAttuali(1)
      await API.updateCarriera(2)
      await API.getAllCourses().then((courses) => {setCorsi(courses);})
      setMessage2({msg: "Piano di studi salvato", type: 'success'})
     }catch(err) { handleErrors(err)}

        }else{
        
      try{
      await  API.saveStudyPlan(newcourses)
      await API.updateStudentiAttuali(1)
      await API.updateCarriera(2)
      await API.getAllCourses().then((courses) => {setCorsi(courses);})
      setpianoStudiAppenaCreato(false)
      setMessage2({msg: "Piano di studi salvato", type: 'success'})
      }catch(err) {handleErrors(err)}
        }
        
  }else{
    setMessage2({msg: "Il numero dei crediti deve essere compreso nelle soglie indicate!", type: 'danger'})
  }
  }

  if(user.carriera === 1){
    if(tot_crediti>=20 && tot_crediti<=40){
    
     
      if(pianoStudiAppenaCreato===false){  
      
   try{
    await API.updateStudentiAttuali(-1)
    await API.deleteStudyPlan()
    await API.saveStudyPlan(newcourses)
    await API.updateStudentiAttuali(1)
    await API.updateCarriera(1)
    await API.getAllCourses().then((courses) => {setCorsi(courses);}) //per aggiornare il numero di studenti 
    setPianoStudi(pianoStudiBis);
    setMessage2({msg: "Piano di studi salvato", type: 'success'})
   }catch(err) { handleErrors(err)}
      }else{
        
    try{
    await API.saveStudyPlan(newcourses)
   await API.updateStudentiAttuali(1)
    await API.updateCarriera(1)
    await API.getAllCourses().then((courses) => {setCorsi(courses);})
    setpianoStudiAppenaCreato(false)
    setPianoStudi(pianoStudiBis); //pianoStudi contiene l'ultima save fatta
    setMessage2({msg: "Piano di studi salvato", type: 'success'})
    }catch(err){handleErrors(err)}
      }

    }else{
      setMessage2({msg: "Il numero dei crediti deve essere compreso nelle soglie indicate!", type: 'danger'})
    }
    }
 
}
}

const deleteStudyPlan = async () => {
  try{
  await API.updateStudentiAttuali(-1).catch(err => handleErrors(err));
  await API.deleteStudyPlan().catch(err => handleErrors(err));
  await API.updateCarriera(0).catch(err => handleErrors(err));
  await API.getAllCourses().then((courses) => {setCorsi(courses);}) 

  setUser(user => {return {matricola: user.matricola, username: user.username, nome: user.nome, 
  cognome: user.cognome, carriera: 0}})
  setMessage2({msg: "Piano di studi cancellato", type: 'danger'})
  }catch(err){handleErrors(err)}
}


function addCourse(course) { 

   let cod_prope = course.propedeutico;
   let lista_codici_incompatibili = course.incompatibilita!==null? course.incompatibilita.split(","): null;


   if(lista_codici_incompatibili!==null){
     //check incompatibilita
                                                                                            //il corso c'è nella lista
     if(lista_codici_incompatibili.length===1 && pianoStudiBis.find(c => c.codice === lista_codici_incompatibili[0])!==undefined){
      course.warning = 1;
      setMessage2({msg: "Non puoi aggiungere un corso incompatibile con quelli già inseriti", type: 'danger'})
      return;
     }
     if(lista_codici_incompatibili.length===2 && (pianoStudiBis.find(c => c.codice === lista_codici_incompatibili[0])!==undefined
     || pianoStudiBis.find(c => c.codice === lista_codici_incompatibili[1])!==undefined) ){
      course.warning = 1;
      setMessage2({msg: "Non puoi aggiungere un corso incompatibile con quelli già inseriti", type: 'danger'})

       return;
   }
  }

   if( course.studentiAttuali!==null && course.maxStudenti!==null && course.studentiAttuali === course.maxStudenti){ //check corso pieno
    course.warning = 1;
    setMessage2({msg: "Il corso è pieno, non si possono più aggiungere studenti", type: 'danger'})
  
     return;
   }


  if (pianoStudiBis.find(c => c.codice === course.codice)===undefined){ //non posso aggiungere un corso che è gia presente nel piano di studi

  
    
      if (cod_prope===null || pianoStudiBis.find(c => c.codice === cod_prope)!==undefined){ //check propeudetico


      setpianoStudiBis(pianoStudiBis => [...pianoStudiBis, course]);
      setCorsi( corsi => corsi.map(c => (c.warning === 1) ? {...c, warning: 0} : c )) 
      //rimetto il warning a 0 dopo che ho inserito un nuovo corso perchè una volta inserito i vincoli precedenti potrebbero 
      //non valere più o non essere più veri
      
    }else{
      course.warning = 1;
      setMessage2({msg: "Corso propeudetico non inserito nel piano di studi", type: 'danger'})
    }

  }else{
    course.warning = 1;
  setMessage2({msg: "Non puoi aggiungere un corso che è gia presente nel piano di studi", type: 'danger'})
  
}
}

function deleteCourse(course) {
 
  //se il corso non è il corso propedeutico di nessun corso nel piano di studi allora lo posso cancellare
     if (pianoStudiBis.find(c => c.propedeutico === course.codice)===undefined){   //check propeudetico

      setpianoStudiBis(pianoStudiBis.filter((c) => c.codice !== course.codice))

      }else{
        setMessage2({msg: "Non puoi cancellare un corso propedeutico", type: 'danger'})
      }

}

  return (
    <>

        <NavBar loggedIn = {loggedIn} setloggedIn = {setloggedIn} doLogOut = {doLogOut} user = {user} setUser = {setUser} />

         {message && <Row>
      <Alert variant={message.type} onClose={() => setMessage('')} dismissible>{message.msg}</Alert>
    </Row> }
          <Routes>
            <Route path='/' element={<ListaCorsi corsi={corsi} setCorsi={setCorsi} loggedIn = {loggedIn} 
            pianoStudi = {pianoStudi} setPianoStudi = {setPianoStudi} user= {user} setUser = {setUser} 
            addCourse = {addCourse} deleteCourse = {deleteCourse} 
            saveStudyPlan = { saveStudyPlan } deleteStudyPlan = {deleteStudyPlan}
             pianoStudiAppenaCreato = {pianoStudiAppenaCreato} setpianoStudiAppenaCreato = {setpianoStudiAppenaCreato}
             pianoStudiBis = {pianoStudiBis} setpianoStudiBis= {setpianoStudiBis}
            message2 = {message2} setMessage2={setMessage2}/>}  />
            
            <Route path = '/login' element = {<LoginForm login = {doLogIn} message = {message} setMessage = {setMessage} /> }/> 
            

            <Route path='*' element={<h1>Page not found</h1>} />
          </Routes>

    </>

  );
}

export default App;

/*
 * All the API calls
 */

//200: success
//300: redirection
//400: client error
//500: server error

//GET per prendere qualcosa dal server
//POST per mandare qualcosa al server
//PUT per aggiornare qualcosa sul server


 const URL = 'http://localhost:3001/api';
 
 //call: GET /courses
 async function getAllCourses() {
   const response = await fetch(URL+'/courses'); 
   const coursesJson = await response.json(); //nel formato json ci sono solo numeri e stringhe, quindi poi devo fare map
   
   if (response.ok) {
     return coursesJson.map((c) => ({codice: c.codice, nome: c.nome, crediti: c.crediti, 
      studentiAttuali: c.studentiAttuali, maxStudenti: c.maxStudenti, incompatibilita: c.incompatibilita, 
      propedeutico: c.propedeutico, esteso: 0, warning: 0}) )
   } else {
     throw coursesJson;  // mi aspetto che sia un oggetto json fornito dal server che contiene l'errore
   }
 }

//call: GET /studyplan
 async function getStudyPlan() {
   
  const response = await fetch(URL+'/studyplan', {credentials: 'include' }); 
  console.log(response);
  const coursesJson = await response.json(); 

  if (response.ok) {
    return coursesJson.map((c) => ({
      codice: c.codice, nome: c.nome, crediti: c.crediti
    }))
  } else {
    throw coursesJson;  
  }
}

 async function logIn(credentials) {
    let response = await fetch(URL+'/sessions', {
      method: 'POST',
      credentials: 'include', 
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });
    if (response.ok) {
      const user = await response.json();
      return user;
    } else {
      const errDetail = await response.json();
      throw errDetail.message;
    }
  } 

  
async function logOut() {
  await fetch(URL+'/sessions/current', { method: 'DELETE', credentials: 'include' });
}

async function getUserInfo() {
  const response = await fetch(URL+'/sessions/current', {credentials: 'include'});
  const userInfo = await response.json();
  if (response.ok) {
    return userInfo;
  } else {
    throw userInfo;
  }
}

  
//call: DELETE /studyplan
const deleteStudyPlan = async () => {
  try {
    
    const response = await fetch(URL+'/studyplan/', {
      method: 'DELETE',
      credentials: 'include'
    });
    if(response.ok)
      return null;
    else {
      const errMessage = await response.json();
      throw errMessage;
    }
  } catch(err){
    throw new Error('Cannot communicate with the server');
  }

}

//call: POST /studyplan
const saveStudyPlan = async (newCourses) => {
  const response = await fetch(URL + '/studyplan/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include',
    body: JSON.stringify(newCourses),
  });
  if(response.ok) {
    return;
  }
  else {
    const errDetails = await response.text();
    throw errDetails;
  }
};

//call: PUT /courses/update
const updateStudentiAttuali = async (flag) => { //flag = 1 => increment, flag = -1 => decrement
  try {
    const response = await fetch(URL+'/courses/update/', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify({flag: flag}),
    });
    if(response.ok){
      return null;
    }
    else {
      const errMessage = await response.json();
      throw errMessage;
    }
  } catch(err){
    throw new Error('Cannot communicate with the server');
  }

}

//call: PUT /students/update
const updateCarriera= async (carriera) => {
  try {
    const response = await fetch(URL+'/students/update/', {
      method: 'PUT',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({carriera: carriera}),
    });
    if(response.ok){
      return null;
    }
    else {
      const errMessage = await response.json();
      throw errMessage;
    }
  } catch(err){
    throw new Error('Cannot communicate with the server');
  }

}


 
 const API = {getAllCourses, logIn, logOut, getUserInfo, 
  getStudyPlan, deleteStudyPlan, saveStudyPlan, updateStudentiAttuali,
  updateCarriera};
 export default API;
'use strict';
/* Data Access Object (DAO) module for accessing courses and exams */

const sqlite = require('sqlite3');

// open the database
const db = new sqlite.Database('courses.db', (err) => {
  if(err) throw err;
});

// get all courses
exports.listCourses = () => {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT * FROM courses';
    db.all(sql, [], (err, rows) => {
      if (err) {
        reject(err);
        return;
      }
      const courses = rows.map((c) => ({ codice: c.codice, nome: c.nome, crediti: c.crediti, maxStudenti: c.maxStudenti, 
       studentiAttuali: c.studentiAttuali, incompatibilita: c.incompatibilita, propedeutico: c.propedeutico }));
      resolve(courses);
    });
  });
};


// get study plan for matricola 
exports.listStudyPlan = (matricola) => {
  console.log(matricola)
  return new Promise((resolve, reject) => {
    const sql =
    'SELECT courses.codice, courses.nome, courses.crediti FROM courses JOIN piano_studi ON courses.codice = piano_studi.codice_corso WHERE matricola = ?';
    db.all(sql, [matricola], (err, rows) => {
      if (err) {
        reject(err);
        return;
      }
      const courses = rows.map((c) => ({ codice: c.codice, nome: c.nome, crediti: c.crediti }));
      resolve(courses);
    });
  });
};


//delete StudyPlan
exports.deleteStudyPlan = (id) => {
  return new Promise((resolve, reject) => {
    //quando faccio una richiesta al server quindi attraverso una sql creo una promise e incapsulo la query li dentro
   //una promise è un oggetto che nel corso del suo ciclo di vita può assumere diversi stati, inizialmente è pending
   //una volta che il server risponde se tutto è andato ok avrà stato fulfilled e ritorna la risposta del server
    const sql = 'DELETE FROM piano_studi WHERE matricola = ?';
    db.run(sql, [id], function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    });
  });
}

//modify the number of enrolled students after a delete
exports.decreaseNumberofEnrolledStudents = (id) => {
  return new Promise((resolve, reject) => {
    const sql = 'update courses set studentiAttuali = courses.studentiAttuali-1 where courses.codice IN (select codice_corso from piano_studi join courses on piano_studi.codice_corso = courses.codice where piano_studi.matricola = ?)';
    db.run(sql, [id], function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    });
  });
}

//modify the number of enrolled students after a save
exports.increaseNumberofEnrolledStudents = (id) => {
  return new Promise((resolve, reject) => {
    const sql = 'update courses set studentiAttuali = courses.studentiAttuali+1 where courses.codice IN (select codice_corso from piano_studi join courses on piano_studi.codice_corso = courses.codice where piano_studi.matricola = ?)';
    db.run(sql, [id], function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    });
  });
}

//modify the carrier option 
exports.updateCarriera = (id, carriera) => {
  return new Promise((resolve, reject) => {
    const sql = 'update students set carriera = ? where matricola = ?';
    db.run(sql, [carriera, id], function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    });
  });
}

//set the carrier option to 0
exports.downgradeCarriera = (id) => {

  return new Promise((resolve, reject) => {
    const sql = 'update students set carriera = 0 where matricola = ?';
    db.run(sql, [id], function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    });
  });
}

//add StudyPlan
exports.saveStudyPlan= (id, newCourses) => {
  return new Promise((resolve, reject) => {
    for ( let i = 0; i<newCourses.length; i++){
     let newCourse = newCourses[i];
    
    const sql = 'insert into piano_studi values (?, ?)';
    db.run(sql, [id, newCourse],function (err) {
      if(err) {
        reject(err);
        return;
      } else
      resolve(null);
    }); 
  }
  }  ); 
}
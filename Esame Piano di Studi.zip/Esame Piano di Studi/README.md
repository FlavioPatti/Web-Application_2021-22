# Exam #1: "Piano Studi"
## Student: s301104 PATTI FLAVIO 

## React Client Application Routes

- Route `/`: main page containing all courses when the user is not loggin and all courses with the (eventual) study plan when the user is loggin
- Route `/login`: login required to access the study plan

## API Server

### __Get couses__
URL:  `/api/courses`

Method: GET

Description: Get all the courses that the student needs to pass.

Request body: None

Response: 200 OK (success) or 500 Internal Server Error (generic error).

Response body: An array of objects, each describing a course.

[{
    "codice": "01TYMOV",
    "nome": " Information systems security ",
    "crediti": 6,
    "maxStudenti": 3
    "studentiAttuali": 0
    "incompatibilita": "02LSEOV"
    "propedeutico": null

}, 
{
    "codice": "01TYMOV",
    "nome": "Architetture e sistemi di elaborazione ",
    "crediti": 12,
    "maxStudenti": 2
    "studentiAttuali": 1
    "incompatibilita": null
    "propedeutico": null
},
...
]

### __Get studyplan__
URL:  `/api/studyplan`

Method: GET

Description: Get the studyplan of the student.

Request body: None

Response: 200 OK (success) or 500 Internal Server Error (generic error).

Response body: An array of objects, each describing the studyplan.

[{
    "codice": "01TYMOV",
    "nome": " Information systems security ",
    "crediti": 6,

}, 
{
    "codice": "01TYMOV",
    "nome": "Architetture e sistemi di elaborazione ",
    "crediti": 12,
},
...
]


### __Add a studyplan__
URL: `/api/studyplan`

Method: POST

Description: Add a studyplan to a student 

Request body: An array of objects, each describing the code of the course to add in the studyplan.

["02GOLOV","02LSEOV",...]


Response: `201 Created` (success) or `503 Service Unavailable` (generic error, e.g., when trying to insert an already existent course). If the request body is not valid, `422 Unprocessable Entity` (validation error).

Response body: _None_


### __Update the actual students__

URL: `/api/courses/update/`

Method: PUT

Description: Incrementing or decrementing the number of actual students of a course.

Request body: A flag representing the increment or the decrement 
[ 1 ]

Response: `200 OK` (success) or `503 Service Unavailable` (generic error). If the request body is not valid, `422 Unprocessable Entity` (validation error).

Response body: _None_

### __Update the career__

URL: `/api/students/update/`

Method: PUT

Description: Update the career option of a student.

Request body: A number representing career option
[ 2 ]

Response: `200 OK` (success) or `503 Service Unavailable` (generic error). If the request body is not valid, `422 Unprocessable Entity` (validation error).

Response body: _None_


### __Delete a studyplan__

URL: `/api/studyplan/`

Method: DELETE

Description: Delete an existing studyplan from a student.

Request body: _None_

Response: `204 No Content` (success) or `503 Service Unavailable` (generic error).

Response body: _None_

## Database Tables

- Table `courses` - contains: codice nome crediti maxStudenti incompatibilita prepedeutico
- Table `credentials` - contains: matricola email password salt
- Table `piano_studi` - contains: matricola codice_corso
- Table `students` - contains: matricola nome cognome carriera


## Main React Components

- `ListaCorsi` (in `ListaCorsi.js`): show all the courses
- `LoginForm` (in `LoginForm.js`): to authenticate users
- `FormPianoStudi` (in `FormPianoStudi.js`): to create a study plan for a student
- `NavBar` (in `NavBar.js`): show the logo of the university and login/logout button
- `PianoStudi` (in `PianoStudi.js`): show the study plan of a student


## Screenshot

![Screenshot](./Screenshot.png)

## Users Credentials

- s301104@studenti.polito.it, password1
- s301216@studenti.polito.it, password2
- s305895@studenti.polito.it, password3
- s302948@studenti.polito.it, password4
- s299401@studenti.polito.it, password5

